create view most_popular_fields as
  select distinct `i`.`fieldnum` AS `fieldnum`
  from `dbc18b3623386`.`interest` `i`
  where `i`.`fieldnum` in (select `fv`.`fieldnum`
                           from `dbc18b3623386`.`fields_order_by_popularity` `fv`
                           where (`fv`.`num_ac_interested` = (select max(`fv1`.`num_ac_interested`)
                                                              from `dbc18b3623386`.`fields_order_by_popularity` `fv1`)));

