create view fields_order_by_popularity as
  select `i`.`fieldnum` AS `fieldnum`, count(0) AS `num_ac_interested`
  from `dbc18b3623386`.`academic` `a`
         join `dbc18b3623386`.`interest` `i`
  where (`a`.`acnum` = `i`.`acnum`)
  group by `i`.`fieldnum`
  order by count(0) desc;

