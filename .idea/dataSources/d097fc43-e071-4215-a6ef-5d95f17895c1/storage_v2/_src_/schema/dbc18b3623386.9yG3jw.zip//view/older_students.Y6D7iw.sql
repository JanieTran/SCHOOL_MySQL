create view older_students as
  select `S`.`gname` AS `given_name`, `S`.`age` AS `age`
  from `dbc18b3623386`.`students` `S`
  where (`S`.`age` >= 22);

